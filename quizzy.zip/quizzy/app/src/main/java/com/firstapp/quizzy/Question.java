package com.firstapp.quizzy;

public class Question {
    String question;       // The question text
    String[] answers;      // Array holding all four possible answers
    String correctAnswer;  // The correct answer

    // Constructor to create a question object
    public Question(String question, String[] answers, String correctAnswer) {
        this.question = question;
        this.answers = answers;
        this.correctAnswer = correctAnswer;
    }
}
