package com.firstapp.quizzy;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView questionTextView, scoreTextView;
    private Button answerButton1, answerButton2, answerButton3, answerButton4;
    private Button addQuestionButton, startQuizButton;
    private EditText questionInput, answerInput1, answerInput2, answerInput3, answerInput4;
    private List<Question> questionList = new ArrayList<>();
    private int score = 0;
    private int currentQuestionIndex = 0;

    private static class Question {
        String question;
        List<String> answers;
        String correctAnswer;

        public Question(String question, List<String> answers, String correctAnswer) {
            this.question = question;
            this.answers = answers;
            this.correctAnswer = correctAnswer;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        questionTextView = findViewById(R.id.questionTextView);
        scoreTextView = findViewById(R.id.scoreTextView);
        answerButton1 = findViewById(R.id.answerButton1);
        answerButton2 = findViewById(R.id.answerButton2);
        answerButton3 = findViewById(R.id.answerButton3);
        answerButton4 = findViewById(R.id.answerButton4);
        questionInput = findViewById(R.id.questionInput);
        answerInput1 = findViewById(R.id.answerInput1);
        answerInput2 = findViewById(R.id.answerInput2);
        answerInput3 = findViewById(R.id.answerInput3);
        answerInput4 = findViewById(R.id.answerInput4);
        addQuestionButton = findViewById(R.id.addQuestionButton);
        startQuizButton = findViewById(R.id.startQuizButton);

        // Add question functionality
        addQuestionButton.setOnClickListener(v -> addQuestion());

        // Start quiz functionality
        startQuizButton.setOnClickListener(v -> startQuiz());

        // Answer button functionality
        answerButton1.setOnClickListener(v -> checkAnswer(answerButton1.getText().toString()));
        answerButton2.setOnClickListener(v -> checkAnswer(answerButton2.getText().toString()));
        answerButton3.setOnClickListener(v -> checkAnswer(answerButton3.getText().toString()));
        answerButton4.setOnClickListener(v -> checkAnswer(answerButton4.getText().toString()));
    }

    private void addQuestion() {
        String question = questionInput.getText().toString();
        List<String> answers = new ArrayList<>();
        answers.add(answerInput1.getText().toString());
        answers.add(answerInput2.getText().toString());
        answers.add(answerInput3.getText().toString());
        answers.add(answerInput4.getText().toString());

        // The correct answer is assumed to be the answer in the first input field
        String correctAnswer = answerInput1.getText().toString();

        // Shuffle the answers to randomize their order
        Collections.shuffle(answers);

        // After shuffling, we need to figure out which one is the correct answer now.
        // The new correct answer will be the one that matches the initial correct answer (before shuffling)
        if (!answers.contains(correctAnswer)) {
            correctAnswer = answers.get(0);  // Reset correct answer based on shuffled order
        }

        // Add the question to the list with shuffled answers
        questionList.add(new Question(question, answers, correctAnswer));

        // Clear input fields
        questionInput.setText("");
        answerInput1.setText("");
        answerInput2.setText("");
        answerInput3.setText("");
        answerInput4.setText("");

        Toast.makeText(this, "Question Added", Toast.LENGTH_SHORT).show();
    }

    private void startQuiz() {
        // Hide input fields and buttons when the quiz starts
        questionInput.setVisibility(View.GONE);
        answerInput1.setVisibility(View.GONE);
        answerInput2.setVisibility(View.GONE);
        answerInput3.setVisibility(View.GONE);
        answerInput4.setVisibility(View.GONE);
        addQuestionButton.setVisibility(View.GONE);
        startQuizButton.setVisibility(View.GONE);

        // Show the answer buttons and question
        answerButton1.setVisibility(View.VISIBLE);
        answerButton2.setVisibility(View.VISIBLE);
        answerButton3.setVisibility(View.VISIBLE);
        answerButton4.setVisibility(View.VISIBLE);
        scoreTextView.setVisibility(View.VISIBLE);

        // Randomize the order of the questions
        Collections.shuffle(questionList);

        // Start the quiz
        currentQuestionIndex = 0;
        score = 0;
        displayQuestion(currentQuestionIndex);
    }

    private void displayQuestion(int index) {
        if (index >= questionList.size()) {
            // Display the final score if no questions left
            Toast.makeText(this, "Quiz Completed! Final Score: " + score, Toast.LENGTH_LONG).show();
            return;
        }

        Question question = questionList.get(index);

        // Update the UI with the question and the options
        questionTextView.setText(question.question);
        answerButton1.setText(question.answers.get(0));
        answerButton2.setText(question.answers.get(1));
        answerButton3.setText(question.answers.get(2));
        answerButton4.setText(question.answers.get(3));
    }

    private void checkAnswer(String answer) {
        Question currentQuestion = questionList.get(currentQuestionIndex);

        if (answer.equals(currentQuestion.correctAnswer)) {
            score++;
            Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Incorrect!", Toast.LENGTH_SHORT).show();
        }

        scoreTextView.setText("Score: " + score);
        currentQuestionIndex++;
        displayQuestion(currentQuestionIndex);

        if (currentQuestionIndex >= questionList.size()) {
            Intent intent = new Intent(MainActivity.this, ScoreActivity.class);
            intent.putExtra("score", score); // Pass the score to ScoreActivity
            startActivity(intent);
        }
    }
}
