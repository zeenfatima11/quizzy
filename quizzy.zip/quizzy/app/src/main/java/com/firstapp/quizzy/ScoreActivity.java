package com.firstapp.quizzy;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ScoreActivity extends AppCompatActivity {

    private TextView scoreTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        // Initialize the scoreTextView
        scoreTextView = findViewById(R.id.scoreTextView);

        // Get the score from the Intent
        int score = getIntent().getIntExtra("score", 0);

        // Display the score
        scoreTextView.setText("Your Score: " + score);
    }
}
